from flask import Flask
import os
from flask.ext.sqlalchemy import SQLAlchemy
# import pdb;pdb.set_trace()
from flask_mail import Mail
mail = Mail()
basedir = os.path.abspath(os.path.dirname(__file__))[:-4]
def readConfig():
	config = {}
	fp = open(basedir+'/app.config','r')
	lstData = fp.readlines()
	print lstData
	for i in lstData:
		print i
		if i[0] == '#':
			continue
		i = i.replace('\n','').replace('\t','').replace(' ','').replace('"','').replace("'",'')
		if '=' in i:
			config[i.split('=')[0].strip()] = i.split('=')[1].strip()
	return config


app = Flask(__name__)
app.config.update(
	DEBUG=True,
	#EMAIL SETTINGS
	MAIL_SERVER='smtp.gmail.com',
	MAIL_PORT=465,
	MAIL_USE_SSL=True,
	MAIL_USERNAME = 'swiftvault@gmail.com',
	MAIL_PASSWORD = 'vaultbm1547'
	)

mail=Mail(app)
os.chdir(os.environ['HOME'])
config = {}
config = readConfig()
app.secret_key = 'super secret key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqldb://'+config['dbUserName']+':'+config['dbPassword']+'@'+config['dbHostName']+'/'+config['dbName']
db = SQLAlchemy(app)


from app.views import views





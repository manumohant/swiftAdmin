function addContainer()
{
	var strContainerName = document.getElementById('containerName').value;
	var strContainerSize = document.getElementById('containerSize').value;
	if(strContainerName == '')
	{
		$.notify("Field cannot be empty", "info");
		document.getElementById('containerName').focus();
		return
	}
    if(strContainerSize == '')
	{
		$.notify("Field cannot be empty", "info");
		document.getElementById('containerSize').focus();
		return
	}
	$.ajax({
    	url: '/addContainer',
        data: JSON.stringify({'containerName':strContainerName,'containerSize':strContainerSize}),
        type: 'POST',
        contentType: 'application/json;charset=UTF-8',
    	success: function(response) 
	    {
	        if(response.result[0].success == true)
	        {
	           $.notify("Container created", "success");
	           document.getElementById('containerName').value = '';
			   document.getElementById('containerSize').value = '';
	           getContainerDetails();
	        }
	        else{
	        	$.notify("Container not created","warn");
	        	document.getElementById('containerName').value = '';
			    document.getElementById('containerSize').value = '';
	        }
	    }  
    });
}

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

function getContainerDetails()
{
	$.ajax({
	    	url: '/getContainerDetails',
	        // data: JSON.stringify({'strUserName':strUserName,'strPassword':strPassword,'strRole':strRole}),
	        type: 'POST',
	        // contentType: 'application/json;charset=UTF-8',
	    	success: function(response) 
		    {	
		    	var table = document.getElementById("containerTable");
		           	table.innerHTML = '';
		           	var tr = document.createElement("TR");
		           	var td0 = document.createElement("TD");
		           		td0.innerHTML = "created Date";
		           		td0.style.padding = "5px 0px 5px 0px";
		           		tr.appendChild(td0);

		           		var td1 = document.createElement("TD");
		           		td1.innerHTML = "User";
		           		td1.style.padding = "5px 0px 5px 0px";
		           		tr.appendChild(td1);

		           		var td2 = document.createElement("TD");
		           		td2.innerHTML = "Container";
		           		td2.style.padding = "5px 0px 5px 0px";
		           		tr.appendChild(td2);

		           		var td3 = document.createElement("TD");
		           		td3.innerHTML = "Id";
		           		td3.style.padding = "5px 0px 5px 0px";
		           		td3.style.display='none';
		           		tr.appendChild(td3);

						var td4 = document.createElement("TD");
		           		td4.innerHTML = "Size";
		           		td4.style.padding = "5px 0px 5px 0px";
		           		td4.style.textAlign='center';
		           		tr.appendChild(td4);

		           		var td5 = document.createElement("TD");
		           		td5.innerHTML = "Used Size";
		           		td5.style.textAlign='center';
		           		td5.style.padding = "5px 0px 5px 0px";
		           		tr.appendChild(td5);

						var td6 = document.createElement("TD");
		           		td6.innerHTML = "Free Size";
		           		td6.style.textAlign='center';
		           		td6.style.padding = "5px 0px 5px 0px";
		           		tr.appendChild(td6);

		           		var td8 = document.createElement("TD");
		           		td8.style.padding = "5px 0px 5px 0px";
		           		td8.innerHTML ="Delete";
		           		tr.appendChild(td8);
		           		tr.style.background = "rgb(186, 219, 234)";

		           		var td9 = document.createElement("TD");
		           		td9.style.padding = "5px 0px 5px 0px";
		           		td9.innerHTML ="Clean";
		           		tr.appendChild(td9);
		           		tr.style.background = "rgb(186, 219, 234)";

		       		table.appendChild(tr);


		        if(response.result[0].success == true)
		        {
		           // location.reload();
		            
		           // table.style.border = "solid 1px";
		           for(var i=1;i<response.result.length;i++)
		           {

		           		var data = response.result;
		           		var tr = document.createElement("TR");
		           		tr.id = i
		           		if(i%2 == 0)
		           			{
		           				tr.style.background = "#FFFFFF";}
		           		else
		           			{ tr.style.background = "#ebeff2";}
		           		// appendChild(tr)
		           		var td0 = document.createElement("TD");
		           		td0.innerHTML = data[i].createdDate;
		           		td0.style.padding = "5px 0px 5px 0px";
		           		tr.appendChild(td0);

		           		var td1 = document.createElement("TD");
		           		td1.innerHTML = data[i].userName;
		           		td1.style.padding = "5px 0px 5px 0px";
		           		tr.appendChild(td1);

		           		

		           		var td2 = document.createElement("TD");
		           		td2.innerHTML = data[i].containerName;
		           		td2.style.padding = "5px 0px 5px 0px";
		           		tr.appendChild(td2);

		           		var td3 = document.createElement("TD");
		           		td3.innerHTML = data[i].rowId;
		           		td3.style.padding = "5px 0px 5px 0px";
		           		td3.style.display='none';
		           		tr.appendChild(td3);

						var td4 = document.createElement("TD");
		           		td4.innerHTML = data[i].size;
		           		td4.style.padding = "5px 0px 5px 0px";
		           		td4.style.textAlign='right';
		           		tr.appendChild(td4);

		           		var td5 = document.createElement("TD");
		           		td5.innerHTML = data[i].usedSize;
		           		td5.style.textAlign='right';
		           		td5.style.padding = "5px 0px 5px 0px";
		           		tr.appendChild(td5);

						var td6 = document.createElement("TD");
		           		td6.innerHTML = data[i].freeSize;
		           		td6.style.textAlign='right';
		           		td6.style.padding = "5px 0px 5px 0px";
		           		tr.appendChild(td6);

		           		

		           		var td8 = document.createElement("TD");
		           		rowid = JSON.stringify(i).replace(/"/g,"&quot;")
		           		td8.style.padding = "5px 0px 5px 0px";
		           		td8.style.textAlign='center';
		           		td8.innerHTML ="<input name='Delete' class='button1' type='button' value='Delete' onclick='deleteContainer("+rowid+")'/>";
		           		tr.appendChild(td8);

		           		var td9 = document.createElement("TD");
		           		rowid = JSON.stringify(i).replace(/"/g,"&quot;")
		           		td9.style.padding = "5px 0px 5px 0px";
		           		td9.innerHTML ="<input name='Clean' class='button1' type='button' value='Clean' title='Delete all data from container' onclick='cleanContainer("+rowid+")'/>";
		           		tr.appendChild(td9);

		           		table.appendChild(tr);


	           		}


		        }
		        
		    }  
	    	});	
}

function deleteContainer(rowId)
{
	var row =  document.getElementById(rowId);
    var tdArr = row.children;
    var strContainerName = tdArr[2].innerText;
    var strId = tdArr[3].innerText;
    var res = window.confirm("Do you want to delete "+strContainerName);
   	if(res == true)
   	{
	   	$.ajax({
	    	url: '/deleteContainer',
	        data: JSON.stringify({'strId':strId,'strContainerName':strContainerName}),
	        type: 'POST',
	        contentType: 'application/json;charset=UTF-8',
	    	success: function(response) 
		    {
		        if(response.result[0].success == true)
		        {
		        	$.notify(response.result[0].msg,"success");
		           getContainerDetails();
		        }
		        else{
		        	$.notify(response.result[0].msg,"warn");
		        }
		    }  
	    });
   }
}

function cleanContainer(rowId)
{
	var row =  document.getElementById(rowId);
    var tdArr = row.children;
    var strContainerName = tdArr[2].innerText;
    var strId = tdArr[3].innerText;
    var res = window.confirm("Do you want to delete all object from "+strContainerName);
   	if(res == true)
   	{
	   	$.ajax({
	    	url: '/cleanContainer',
	        data: JSON.stringify({'strId':strId,'strContainerName':strContainerName}),
	        type: 'POST',
	        contentType: 'application/json;charset=UTF-8',
	    	success: function(response) 
		    {
		        if(response.result[0].success == true)
		        {
		        	$.notify(response.result[0].msg,"success");
		           getContainerDetails();
		        }
		        else{
		        	$.notify(response.result[0].msg,"warn");
		        }
		    }  
	    });
   }
}

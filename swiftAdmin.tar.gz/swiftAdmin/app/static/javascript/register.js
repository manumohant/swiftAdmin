
document.getElementById('userName').focus()
$("#register").on("submit", function(e){

	var strUserName = document.getElementById('userName').value.trim();
	var strEmailId = document.getElementById('emailId').value.trim();
	var strCompanyName = document.getElementById('companyName').value.trim();
	
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
	// alert(strUserName);
	// alert(strPassword);
	if(strUserName =='')
	{
		$.notify("Field cannot be empty","info");
		document.getElementById('userName').focus()
		return false
	}
	else if(strEmailId == '')
	{
		$.notify("Field cannot be empty","info");
		document.getElementById('emailId').focus()
		return false
	}
	else if(strEmailId.match(mailformat)==null)
	{
		
		// alert(strEmailId.match(mailformat));
		if(strEmailId.match(mailformat) == null)  
			{  
			    $.notify("Invalid email id","info");
				document.getElementById('emailId').focus()
				return false;
			}
	}

	else if(strCompanyName == '')
	{
		$.notify("Field cannot be empty","info");
		document.getElementById('companyName').focus()
		return false
	}
	else{e.preventDefault();
		document.getElementById('loadingDiv').style.display = '';
	$.ajax({
    	url: '/register',
        data: JSON.stringify({'userName':strUserName,'emailId':strEmailId,'companyName':strCompanyName}),
        type: 'POST',
        contentType: 'application/json;charset=UTF-8',
    	success: function(response) 
	    {
	    	// alert(JSON.stringify(response));
	        if(response.result.success == true)
	        {
	        	document.getElementById('loadingDiv').style.display = 'none';
	        	alert("Your request has been saved, credentials will be sent to your email")
	            window.location.href = "/"
	        }
	        else{
	        	document.getElementById('loadingDiv').style.display = 'none';
	        	$.notify(response.result.msg,"error");
	        }
	    }  
    });}
	
    
});
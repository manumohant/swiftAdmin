function addUser()
{
	var strUserName =  document.getElementById('userName').value.trim();
	var strPassword =  document.getElementById('password').value.trim();
	var strRePassword =  document.getElementById('rePassword').value.trim();
	var strRole =  document.getElementById('cboRole').value.trim();
	var strContainer =  document.getElementById('cboContainer').value.trim();
	if(strContainer == "none")
	{
		strContainer = "";

	}
	if (strUserName == '')
	{
		$.notify("Field cannot be empty ","info");
		document.getElementById('userName').focus();
		return
	}
	if (strPassword == '')
		{
			$.notify("Field cannot be empty ","info");
			document.getElementById('password').focus();
			return
		}
	if (strRePassword == '')
		{
			$.notify("Field cannot be empty ","info");
			document.getElementById('userName').focus();
			return
		}
	if (strRePassword !=strPassword )
		{
			$.notify("Password should be same ","info");
			document.getElementById('rePassword').focus();
			return
		}

	$.ajax({
	    	url: '/addUser',
	        data: JSON.stringify({'strUserName':strUserName,'strPassword':strPassword,'strRole':strRole,"strContainer":strContainer}),
	        type: 'POST',
	        contentType: 'application/json;charset=UTF-8',
	    	success: function(response) 
		    {
		        if(response.result[0].success == true)
		        {
		           $.notify("User added","info");
		           getUsers();
		        }
		        else{
		        	$.notify("user creation failed","info");
		        }
		    }  
	    	});	


}

function getUsers()
{
	$.ajax({
	    	url: '/getUser',
	        // data: JSON.stringify({'strUserName':strUserName,'strPassword':strPassword,'strRole':strRole}),
	        type: 'POST',
	        // contentType: 'application/json;charset=UTF-8',
	    	success: function(response) 
		    {	
		    	var table = document.getElementById("userTable");
		           	table.innerHTML = '';
		           	var tr = document.createElement("TR");
		           	var td0 = document.createElement("TD");
		       		td0.innerHTML = "Created Date";
		       		td0.style.padding = "5px 0px 5px 0px";
		       		tr.appendChild(td0);

		       		var td1 = document.createElement("TD");
		       		td1.innerHTML = "User Name";
		       		td1.style.padding = "5px 0px 5px 0px";
		       		tr.appendChild(td1);

		       		var td2 = document.createElement("TD");
		       		td2.innerHTML = "Role";
		       		td2.style.padding = "5px 0px 5px 0px";
		       		tr.appendChild(td2);

		       		var td3 = document.createElement("TD");
	           		td3.innerHTML = "Container";
	           		td3.style.padding = "5px 0px 5px 0px";
		           	tr.appendChild(td3);

		       		var td4 = document.createElement("TD");
		       		td4.innerHTML = "Id";
		       		td4.style.padding = "5px 0px 5px 0px";
		       		td4.style.display='none';
		       		tr.appendChild(td4);

		       		var td5 = document.createElement("TD");
		       		td5.innerHTML = "Edit";
		       		td5.style.padding = "5px 0px 5px 0px";
		       		tr.appendChild(td5);

		       		var td6 = document.createElement("TD");
		       		td6.innerHTML = "Delete";
		       		td6.style.padding = "5px 0px 5px 0px";
		       		tr.appendChild(td6);

		       		tr.style.background = "rgb(186, 219, 234)"
		       		table.appendChild(tr);
		        if(response.result[0].success == true)
		        {
		           // location.reload();
		            


		           // table.style.border = "solid 1px";
		           for(var i=1;i<response.result.length;i++)
		           {

		           		var data = response.result;
		           		var tr = document.createElement("TR");
		           		tr.id = i
		           		if(i%2 == 0)
		           			{
		           				tr.style.background = "#FFFFFF";}
		           		else
		           			{ tr.style.background = "#ebeff2";}
		           		// appendChild(tr)
		           		var td0 = document.createElement("TD");
		           		td0.innerHTML = data[i].createdDate;
		           		td0.style.padding = "5px 0px 5px 0px";
		           		tr.appendChild(td0);

		           		var td1 = document.createElement("TD");
		           		td1.innerHTML = data[i].userName;
		           		td1.style.padding = "5px 0px 5px 0px";
		           		tr.appendChild(td1);

		           		var td2 = document.createElement("TD");
		           		td2.innerHTML = data[i].role;
		           		td2.style.padding = "5px 0px 5px 0px";
		           		tr.appendChild(td2);

		           		var td3 = document.createElement("TD");
		           		td3.innerHTML = data[i].containerName;
		           		td3.style.padding = "5px 0px 5px 0px";
		           		tr.appendChild(td3);

		           		var td4 = document.createElement("TD");
		           		td4.innerHTML = data[i].id;
		           		td4.style.padding = "5px 0px 5px 0px";
		           		td4.style.display='none';
		           		tr.appendChild(td4);

		           		var td5 = document.createElement("TD");
		           		rowid = JSON.stringify(i).replace(/"/g,"&quot;")
		           		td5.style.padding = "5px 0px 5px 0px";
		           		td5.innerHTML = "<input name='Edit' class='button1' type='button' value='Edit' onclick='getRowValues("+rowid+")'/>";
		           		tr.appendChild(td5);

		           		var td6 = document.createElement("TD");
		           		rowid = JSON.stringify(i).replace(/"/g,"&quot;")
		           		td6.style.padding = "5px 0px 5px 0px";
		           		td6.innerHTML ="<input name='Delete' class='button1' type='button' value='Delete' onclick='deleteUser("+rowid+")'/>";
		           		tr.appendChild(td6);

		           		table.appendChild(tr);


	           		}


		        }
		        
		    }  
	    	});	
}

function userOnBlur()
{
	var strUserName = document.getElementById("userName").value.trim();
	$.ajax({
	    	url: '/getUserDetails',
	        data: JSON.stringify({'strUserName':strUserName}),
	        type: 'POST',
	        contentType: 'application/json;charset=UTF-8',
	    	success: function(response) 
		    {
		        if(response.result[0].success == true)
		        {
		            $.notify(strUserName + " already exist. ","info");
		        	document.getElementById("userName").value = response.result[1].userName;
		        	document.getElementById("rowId").value = response.result[1].id;
		        	var contSelect = document.getElementById("cboContainer");
		        	if(contSelect == "")
		        	{
		        		contSelect.selectedIndex = 0;
		        	}
		        	for(var i, j = 0; i = contSelect.options[j]; j++) 
		        	{
						    if(i.value == response.result[1].containerName) 
						    {
						        contSelect.selectedIndex = j;
						        break;
						    }
					}

		        	if(response.result[1].role == 'user')

		        		{ document.getElementById("cboRole").selectedIndex= 1;}
		        	else
		        		{document.getElementById("cboRole").value = 0;}
		        	document.getElementById("editUser").style.display = "";
		        	document.getElementById("addUser").style.display = "none";
		        	document.getElementById("lblUserName").innerHTML = response.result[1].userName;



	           	}
	           	else{
	           			document.getElementById("editUser").style.display = "none";
		        		document.getElementById("addUser").style.display = "";
		        		document.getElementById("rowId").value = "";
		        		document.getElementById("cboContainer").selectedIndex = 0;
		        		document.getElementById("lblUserName").innerHTML = " ";
	           		}

		        
		    }

	    });	

}

function clearUser()
{
	document.getElementById('userName').value="";
	document.getElementById('password').value="";
	document.getElementById('rePassword').value="";
	document.getElementById('cboRole').selectedIndex=0;
	document.getElementById('cboContainer').selectedIndex=0;
	document.getElementById("editUser").style.display = "none";
	document.getElementById("addUser").style.display = "";
	document.getElementById("rowId").value = "";
	document.getElementById("lblUserName").innerHTML = " ";
}

function getRowValues(rowId)
{
    var row =  document.getElementById(rowId);
    var tdArr = row.children;
    var strUserName = tdArr[1].innerText;
    var strId = tdArr[4].innerText;

    document.getElementById("userName").value = strUserName;
    document.getElementById("rowId").value = strId;
    userOnBlur();

}

function deleteUser(rowId)
{
	var row =  document.getElementById(rowId);
    var tdArr = row.children;
    var strUserName = tdArr[1].innerText;
    var strId = tdArr[4].innerText;
    var strContainerName = tdArr[3].innerText;
    var res = window.confirm("Do you want to delete "+strUserName);
   	if(res == true)
   	{
	   	$.ajax({
	    	url: '/deleteUser',
	        data: JSON.stringify({'userId':strId,'userName':strUserName,'container':strContainerName}),
	        type: 'POST',
	        contentType: 'application/json;charset=UTF-8',
	    	success: function(response) 
		    {
		        if(response.result[0].success == true)
		        {
		           getUsers();
		           containerList();
		        }
		        else{
		        	alert("Deletion failed");
		        }
		    }  
	    });

   }

   

}

function containerList()
{
	var container = document.getElementById("cboContainer");
	container.innerHTML = "";
	var option = document.createElement("option");
    option.text = '<<Select>>';
    option.value = "";
    container.appendChild(option)
	
	$.ajax({
	    	url: '/getContainer',
	        // data: JSON.stringify({'userId':strId,'userName':strUserName}),
	        type: 'POST',
	        // contentType: 'application/json;charset=UTF-8',
	    	success: function(response) 
		    {
		        if(response.result[0].success == true)
		        {
		        	 for(var i=1;i<response.result.length;i++)
		           {
			            var option = document.createElement("option");
					    option.text = response.result[i].containerName;
					    option.value = response.result[i].containerName;
					    container.appendChild(option)
					}
		        }
		        
		    }  
	    	});

}

function editUser()
{
	var strID = document.getElementById("rowId").value
	var strUserNameTemp = document.getElementById("lblUserName").innerHTML;
	if(strID != '')
	{
		var strUserName =  document.getElementById('userName').value.trim();
		var strPassword =  document.getElementById('password').value.trim();
		var strRePassword =  document.getElementById('rePassword').value.trim();
		var strRole =  document.getElementById('cboRole').value.trim();
		var strContainer =  document.getElementById('cboContainer').value.trim();
		if(strContainer == "none")
		{
			strContainer = "";

		}
		if (strUserName == '')
		{
			$.notify('userName',"Field cannot be empty ","info");
			document.getElementById('userName').focus();
			return
		}
		if (strPassword != '' && strRePassword == '')
			{
				$.notify('rePassword',"Field cannot be empty ","info");
				document.getElementById('rePassword').focus();
				return
			}
		if (strRePassword !=strPassword )
			{
				$.notify('rePassword',"Password should be same ","info");
				document.getElementById('rePassword').focus();
				return
			}

		var res = window.confirm("Do you want to update "+strUserNameTemp);
	   	if(res == true)
	   	{
			$.ajax({
		    	url: '/editUser',
		        data: JSON.stringify({'strId':strID,'strUserName':strUserName,'strPassword':strPassword,'strRole':strRole,"strContainer":strContainer}),
		        type: 'POST',
		        contentType: 'application/json;charset=UTF-8',
		    	success: function(response) 
			    {
			        if(response.result[0].success == true)
			        {
			           $.notify("User data updated","info");
			           location.reload()
			        }
			        else{
			        	$.notify("user updation failed","info");
			        }
			    }  
		    	});	
			}
	}
	else{location.reload();}
}





document.getElementById('userName').focus()
$("#request").on("submit", function(e){

	var strUserName = document.getElementById('userName').value.trim();
	var strPassword = document.getElementById('password').value.trim();
	var strTenantName = document.getElementById('tenantName').value.trim();
	document.getElementById('loadingDiv').style.display = '';
	// alert(strUserName);
	// alert(strPassword);
	if(strUserName =='')
	{
		$.notify("Field cannot be empty","info");
		document.getElementById('userName').focus()
		return
	}
	if(strPassword == '')
	{
		$.notify("Field cannot be empty","info");
		document.getElementById('password').focus()
		return
	}
	if(strTenantName == '')
	{
		$.notify("Field cannot be empty","info");
		document.getElementById('tenantName').focus()
		return
	}
	e.preventDefault();
    $.ajax({
    	url: '/checkLogin',
        data: JSON.stringify({'userName':strUserName,'password':strPassword,'tenantName':strTenantName}),
        type: 'POST',
        contentType: 'application/json;charset=UTF-8',
    	success: function(response) 
	    {
	    	// alert(JSON.stringify(response));
	        if(response.result.success == true)
	        {
	        	document.getElementById('loadingDiv').style.display = 'none';
	           window.location.href = "/home"
	           
	        }
	        else{
	        	document.getElementById('loadingDiv').style.display = 'none';
	        	$.notify("Login failure","info");

	        }
	    }  
    });
});
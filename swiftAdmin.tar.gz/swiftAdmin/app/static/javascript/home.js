
var accDict = {};
function onHomeLoad()
{
	document.getElementById('loadingDiv').style.display = '';
	$.ajax({
    	url: '/getFileDetails',
        // data: JSON.stringify({'from':from,'to':to,'file_name':file_name}),
        // data:,
        type: 'POST',
        contentType: 'application/json;charset=UTF-8',
    	success: function(response) 
	    {
	    	// alert(JSON.stringify(response));
	    	// alert(response)
	        if(response.result.success == true)
	        {
	           // window.location.href = "/home"
	           dataDiv.style.display = '';
	           var table = document.getElementById("dataTable");
	           table.innerHTML = '';
	           var tr = document.createElement("TR");
	           var td0 = document.createElement("TD");
	     //       chkID = '"'+JSON.stringify(0).concat('r')+'"'
			   // chkID = chkID.replace(/"/g,"&quot;")
	           	td0.innerHTML = "<input type='checkbox' value=0 onclick='selectAll(this)'/>";
	       		td0.style.padding = "5px 0px 5px 0px";
	       		td0.align = 'center';
	       		tr.appendChild(td0);
	           

	       		var td1 = document.createElement("TD");
	       		td1.innerHTML = "Accounts";
	       		td1.style.padding = "5px 0px 5px 0px";
	       		td1.align = 'center';
	       		tr.appendChild(td1);

	       		var td2 = document.createElement("TD");
	       		td2.innerHTML = "Containers";
	       		td2.style.padding = "5px 0px 5px 0px";
	       		td2.align = 'center';
	       		tr.appendChild(td2);

	       		var td3 = document.createElement("TD");
	       		td3.innerHTML = "Users";
	       		td3.style.padding = "5px 0px 5px 0px";
	       		td3.align = 'center';
	       		tr.appendChild(td3);

	       		tr.style.background = "rgb(186, 219, 234)"
	       		table.appendChild(tr);


	           // table.style.border = "solid 1px";
	           var count =1 ;
	           // alert(JSON.stringify(response.result.data))
	           for(var pro in response.result.data)
	           {    

	           		var tr = document.createElement("TR");
	           		tr.id = count
	           		if(count%2 == 0)
	           			{ tr.className = "trcl1";
	           				}
	           		else
	           			{ tr.className = "trcl2";
	           				}
	           			
	           		var td0 = document.createElement("TD");
		           	td0.innerHTML = "<input type='checkbox' value="+count+">";
		       		td0.style.padding = "5px 0px 5px 0px";
		       		td0.align = 'center';
		       		// td0.addEventListener('click', tdClick.bind(null,count));
		       		tr.appendChild(td0);
		       		var arrCon = [];
		       		// alert(pro);
		       		// alert(response.result.data[pro]);
		       		for(var con in response.result.data[pro])
		       		{
		       			if(con == "projectUsers")
		       			{var users = response.result.data[pro].projectUsers.join()}
		       			else{arrCon.push(con)}
		       		}
		       		accDict[pro] = arrCon;
	           		var td1 = document.createElement("TD");
	           		td1.innerHTML = pro;
	           		td1.style.padding = "5px 0px 5px 0px";
	           		td1.align = 'center';
	           		td1.addEventListener('click', tdClick.bind(null,count,''));
	           		tr.appendChild(td1);

	           		var td2 = document.createElement("TD");
	           		td2.innerHTML = arrCon.join();
	           		td2.style.padding = "5px 0px 5px 0px";
	           		td2.align = 'center';
	           		td2.addEventListener('click', tdClick.bind(null,count,''));
	           		tr.appendChild(td2);

	           		var td3 = document.createElement("TD");
	           		td3.innerHTML = users;
	           		td3.style.padding = "5px 0px 5px 0px";
	           		td3.align = 'center';
	           		td3.addEventListener('click', tdClick.bind(null,count,''));
	           		tr.appendChild(td3);
	           		count ++;
	           		table.appendChild(tr);
	           		


	           }
	           var table = document.getElementById("showTable");
	           table.innerHTML = '';
	            var tr = document.createElement("TR");
           		var td0 = document.createElement("TD");
	       		td0.style.padding = "5px 0px 5px 0px";
	       		td0.align = 'center';
	       		tr.appendChild(td0);

           		var td1 = document.createElement("TD");
           		td1.style.padding = "5px 0px 5px 0px";
           		td1.align = 'center';
           		tr.appendChild(td1);

           		var td2 = document.createElement("TD");
           		td2.style.padding = "5px 0px 5px 0px";
           		td2.innerHTML = "<input name='Show' class='button1' type='button' value='Show' onclick='showDetails()'/>";
           		td2.align = 'right';
           		tr.appendChild(td2);
           		table.appendChild(tr);


	           document.getElementById('loadingDiv').style.display = 'none';
	           setCboAccount();
	           document.getElementById('pic').value = '';
	        }
	        else{
	        	alert("No data found..");
	        	dataDiv.style.display = 'none';
	        	document.getElementById('loadingDiv').style.display = 'none';
	        	

	        }
	    }  
    });
 

}

function getRowValues(rowId)
{
    var row =  document.getElementById(rowId);
    var tdArr = row.children
    // alert(JSON.stringify(tdArr));
    con = tdArr[2].innerText
    fileName = tdArr[3].innerText
    project = tdArr[7].innerText
	window.open("/download/"+con+"::"+fileName+"::"+project,'_blank');
}

function searchFile()
{
	document.getElementById('loadingDiv').style.display = '';
	var from = document.getElementById('txtFrom').value.trim();
	var to = document.getElementById('txtTo').value.trim();
	var fileName = document.getElementById('txtFileName').value.trim()
	var account = document.getElementById('txtAccount').value.trim()
	var container = document.getElementById('txtContainer').value.trim()
	if(from != '')
	{
		if(checkForm(from) == false)
		{
			document.getElementById('loadingDiv').style.display = 'none';
			document.getElementById('txtFrom').focus()
			$.notify("Enter valid date", "info");
			return
		}
	}
	if(to != '')
	{
		if(checkForm(from) == false)
		{
			document.getElementById('loadingDiv').style.display = 'none';
			document.getElementById('txtTo').focus()
			$.notify("Enter valid date", "info");
			return
		}
	}
	var table = document.getElementById("detailsTable");
	table.innerHTML = '';
	$.ajax({
	    	url: '/searchFile',
	        data: JSON.stringify({'from':from,'to':to,'file_name':fileName,'account':account,'container':container}),
	        type: 'POST',
	        contentType: 'application/json;charset=UTF-8',
	    	success: function(response) 
		    {
		    	// alert(JSON.stringify(response));
		        if(response.result.success == true)
		        {
		        	detailsDiv.style.display = '';
		            var table = document.getElementById("detailsTable");
		            table.innerHTML = '';
		            var tr = document.createElement("TR");
		            var td7 = document.createElement("TD");
		           	td7.innerHTML = "Project";
		       		td7.style.padding = "5px 0px 5px 0px";
		       		td7.align = 'center';
		       		tr.appendChild(td7);

		       		var td0 = document.createElement("TD");
		           	td0.innerHTML = "User";
		       		td0.style.padding = "5px 0px 5px 0px";
		       		td0.align = 'center';
		       		tr.appendChild(td0);

		       		var td1 = document.createElement("TD");
		       		td1.innerHTML = "Container";
		       		td1.style.padding = "5px 0px 5px 0px";
		       		td1.align = 'center';
		       		tr.appendChild(td1);

		       		var td2 = document.createElement("TD");
		       		td2.innerHTML = "File";
		       		td2.style.padding = "5px 0px 5px 0px";
		       		td2.align = 'center';
		       		tr.appendChild(td2);

		       		var td3 = document.createElement("TD");
		       		td3.innerHTML = "Last Modified";
		       		td3.style.padding = "5px 0px 5px 0px";
		       		td3.align = 'center';
		       		tr.appendChild(td3);

		       		var td4 = document.createElement("TD");
		       		td4.innerHTML = "Type";
		       		td4.style.padding = "5px 0px 5px 0px";
		       		td4.align = 'center';
		       		tr.appendChild(td4);

					var td5 = document.createElement("TD");
		       		td5.innerHTML = "Bytes";
		       		td5.style.padding = "5px 0px 5px 0px";
		       		td5.align = 'center';
		       		tr.appendChild(td5);

		       		var td6 = document.createElement("TD");
		       		td6.innerHTML = "Project";
		       		td6.style.padding = "5px 0px 5px 0px";
		       		td6.align = 'center';
		       		td6.style.display = 'none'
		       		tr.appendChild(td6);

		       		var td6 = document.createElement("TD");
		       		td6.innerHTML = "Download";
		       		td6.style.padding = "5px 0px 5px 0px";
		       		td6.align = 'center';
		       		// td6.style.display = 'none'
		       		tr.appendChild(td6);

		       		tr.style.background = "rgb(186, 219, 234)"
		       		table.appendChild(tr);
		       		var count =1 ;

	       		   
	       		   
	       		    
		           for(var pro in response.result.data)
		           {
		           		var users = response.result.data[pro].projectUsers.join()
		           		for(con in response.result.data[pro])
		           		{
		           			// alert(con);
			           		if(con == "projectUsers"){continue;}
			           		for(var files in response.result.data[pro][con])
			           		{	
			           			var tr = document.createElement("TR");
				           		tr.id = JSON.stringify(count).concat('r');
				           		if(count%2 == 0)
				           			{ tr.style.background = "#FFFFFF";
				           				}
				           		else
				           			{ tr.style.background = "#ebeff2";
				           				}
				           			
				           		var td8 = document.createElement("TD");
					           	td8.innerHTML = pro;
					       		td8.style.padding = "5px 0px 5px 0px";
					       		td8.align = 'center';
					       		tr.appendChild(td8);

					       		var td0 = document.createElement("TD");
					           	td0.innerHTML = users;
					       		td0.style.padding = "5px 0px 5px 0px";
					       		td0.align = 'center';
					       		tr.appendChild(td0);

				           		var td1 = document.createElement("TD");
				           		td1.innerHTML = con;
				           		td1.style.padding = "5px 0px 5px 0px";
				           		td1.align = 'center';
				           		tr.appendChild(td1);

				           		var td2 = document.createElement("TD");
				           		strlastModified = response.result.data[pro][con][files].lastModified;
				           		strcontentType = response.result.data[pro][con][files].contentType;
				           		strbytes = response.result.data[pro][con][files].bytes;
				           		files = wordWrap(files,15)
				           		strcontentType = wordWrap(strcontentType,15)
				           		td2.innerHTML = files;
				           		td2.style.padding = "5px 0px 5px 0px";
				           		td2.align = 'center';
				           		tr.appendChild(td2);

				           		var td3 = document.createElement("TD");
					       		td3.innerHTML = strlastModified;
					       		td3.style.padding = "5px 0px 5px 0px";
					       		td3.align = 'center';
					       		tr.appendChild(td3);

					       		var td4 = document.createElement("TD");
					       		td4.innerHTML = strcontentType;

					       		td4.style.padding = "5px 0px 5px 0px";
					       		td4.align = 'center';
					       		tr.appendChild(td4);

					       		var td5 = document.createElement("TD");

					       		rowID = '"'+JSON.stringify(count).concat('r')+'"'
					       		rowID = rowID.replace(/"/g,"&quot;")
					       		td5.innerHTML = strbytes;
					       		td5.style.padding = "5px 0px 5px 0px";
					       		td5.align = 'center';
					       		tr.appendChild(td5);

					       		var td6 = document.createElement("TD");
					       		td6.innerHTML = pro;
					       		td6.style.padding = "5px 0px 5px 0px";
					       		td6.align = 'center';
					       		td6.style.display = 'none'
					       		tr.appendChild(td6);

					       		var td7 = document.createElement("TD");
					       		td7.innerHTML = "<input name='Download' class='button1' type='button' value='Download' onclick='getRowValues("+rowID+")'/>";
					       		td7.style.padding = "5px 0px 5px 0px";
					       		td7.align = 'center';
					       		// td7.style.display = 'none'
					       		tr.appendChild(td7);

					       		count ++;
				           		table.appendChild(tr);
				           	}
				           }

		           	}
		           	document.getElementById('loadingDiv').style.display = 'none';
		        }

		        else{
		        	$.notify("No files found", "error");
		        	document.getElementById('loadingDiv').style.display = 'none';
		        }
		    }  
	    });

	
}

function checkForm(date)
  {
    // regular expression to match required date format
    re = /^\d{1,2}\/\d{1,2}\/\d{4}$/;
    if(date != '' && !date.match(re)) 
    {
      
      return false;
    }
   }

function tdClick(rowId,proName)
{
	document.getElementById('loadingDiv').style.display = '';
	// alert(proName);
	if(proName != '')
	{var project_name = proName}
	else{
		var row =  document.getElementById(rowId);
		var tdArr = row.children;

	    project_name = tdArr[1].innerText;
	}
   	$.ajax({
	    	url: '/getDetails',
	        data: JSON.stringify({'projectName':project_name}),
	        type: 'POST',
	        contentType: 'application/json;charset=UTF-8',
	    	success: function(response) 
		    {
		    	// alert(JSON.stringify(response));
		        if(response.result.success == true)
		        {
		        	detailsDiv.style.display = '';
		            var table = document.getElementById("detailsTable");
		            table.innerHTML = '';
		            var tr = document.createElement("TR");
		            var td7 = document.createElement("TD");
		           	td7.innerHTML = "Project";
		       		td7.style.padding = "5px 0px 5px 0px";
		       		td7.align = 'center';
		       		tr.appendChild(td7);

		       		var td0 = document.createElement("TD");
		           	td0.innerHTML = "User";
		       		td0.style.padding = "5px 0px 5px 0px";
		       		td0.align = 'center';
		       		tr.appendChild(td0);
		           

		       		var td1 = document.createElement("TD");
		       		td1.innerHTML = "Container";
		       		td1.style.padding = "5px 0px 5px 0px";
		       		td1.align = 'center';
		       		tr.appendChild(td1);

		       		var td2 = document.createElement("TD");
		       		td2.innerHTML = "File";
		       		td2.style.padding = "5px 0px 5px 0px";
		       		td2.align = 'center';
		       		tr.appendChild(td2);

		       		var td3 = document.createElement("TD");
		       		td3.innerHTML = "Last Modified";
		       		td3.style.padding = "5px 0px 5px 0px";
		       		td3.align = 'center';
		       		tr.appendChild(td3);

		       		var td4 = document.createElement("TD");
		       		td4.innerHTML = "Type";
		       		td4.style.padding = "5px 0px 5px 0px";
		       		td4.align = 'center';
		       		tr.appendChild(td4);

					var td5 = document.createElement("TD");
		       		td5.innerHTML = "Bytes";
		       		td5.style.padding = "5px 0px 5px 0px";
		       		td5.align = 'center';
		       		tr.appendChild(td5);

		       		var td6 = document.createElement("TD");
		       		td6.innerHTML = "Project";
		       		td6.style.padding = "5px 0px 5px 0px";
		       		td6.align = 'center';
		       		td6.style.display = 'none'
		       		tr.appendChild(td6);

		       		var td6 = document.createElement("TD");
		       		td6.innerHTML = "Download";
		       		td6.style.padding = "5px 0px 5px 0px";
		       		td6.align = 'center';
		       		// td6.style.display = 'none'
		       		tr.appendChild(td6);

		       		tr.style.background = "rgb(186, 219, 234)"
		       		table.appendChild(tr);
		       		var count =1 ;

	       		   
	       		   var users = response.result.data.projectUsers.join()
	       		    
		           for(var con in response.result.data)
		           {
		           		if(con == "projectUsers"){continue;}
		           		for(var files in response.result.data[con])
		           		{	
		           			var tr = document.createElement("TR");
			           		tr.id = JSON.stringify(count).concat('r');
			           		if(count%2 == 0)
			           			{ tr.style.background = "#FFFFFF";
			           				}
			           		else
			           			{ tr.style.background = "#ebeff2";
			           				}
			           			
			           		var td8 = document.createElement("TD");
				           	td8.innerHTML = response.result.project;
				       		td8.style.padding = "5px 0px 5px 0px";
				       		td8.align = 'center';
				       		tr.appendChild(td8);

				       		var td0 = document.createElement("TD");
				           	td0.innerHTML = users;
				       		td0.style.padding = "5px 0px 5px 0px";
				       		td0.align = 'center';
				       		tr.appendChild(td0);

			           		var td1 = document.createElement("TD");
			           		td1.innerHTML = con;
			           		td1.style.padding = "5px 0px 5px 0px";
			           		td1.align = 'center';
			           		tr.appendChild(td1);

			           		var td2 = document.createElement("TD");
			           		strlastModified = response.result.data[con][files].lastModified;
			           		strcontentType = response.result.data[con][files].contentType;
			           		strbytes = response.result.data[con][files].bytes;
			           		files = wordWrap(files,15)
			           		strcontentType = wordWrap(strcontentType,15)
			           		td2.innerHTML = files;
			           		td2.style.padding = "5px 0px 5px 0px";
			           		td2.align = 'center';
			           		tr.appendChild(td2);

			           		var td3 = document.createElement("TD");
				       		td3.innerHTML = strlastModified
				       		td3.style.padding = "5px 0px 5px 0px";
				       		td3.align = 'center';
				       		tr.appendChild(td3);

				       		var td4 = document.createElement("TD");
				       		td4.innerHTML = strcontentType

				       		td4.style.padding = "5px 0px 5px 0px";
				       		td4.align = 'center';
				       		tr.appendChild(td4);

				       		var td5 = document.createElement("TD");

				       		rowID = '"'+JSON.stringify(count).concat('r')+'"'
				       		rowID = rowID.replace(/"/g,"&quot;")
				       		td5.innerHTML = strbytes
				       		td5.style.padding = "5px 0px 5px 0px";
				       		td5.align = 'center';
				       		tr.appendChild(td5);

				       		var td6 = document.createElement("TD");
				       		td6.innerHTML = response.result.project;
				       		td6.style.padding = "5px 0px 5px 0px";
				       		td6.align = 'center';
				       		td6.style.display = 'none'
				       		tr.appendChild(td6);

				       		var td7 = document.createElement("TD");
				       		td7.innerHTML = "<input name='Download' class='button1' type='button' value='Download' onclick='getRowValues("+rowID+")'/>";
				       		td7.style.padding = "5px 0px 5px 0px";
				       		td7.align = 'center';
				       		// td7.style.display = 'none'
				       		tr.appendChild(td7);

				       		count ++;
			           		table.appendChild(tr);
			           	}

		           	}
		           	document.getElementById('loadingDiv').style.display = 'none';
		        }

		        else{
		        	$.notify("File cannot be loaded", "error");
		        	document.getElementById('loadingDiv').style.display = 'none';
		        }
		    }  
	    });

}

function showDetails()
{
	var _rows = document.getElementById("dataTable").rows;
    var i,
	    j,
	    isChecked,
	    inputs;
    // alert(_rows.length);	
   // inputs = _rows[0].getElementsByTagName("input");
   // isChecked = inputs[0].checked;
   var projectNames = [];	       
   for (i=1; i < _rows.length; i++)
   {
      inputs = _rows[i].getElementsByTagName("input");
      for (j=0; j < inputs.length; j++)
      {
	       if(inputs[j].checked == true)
	       {
		      var tdArr = _rows[i].children;
		      projectNames.push(tdArr[1].innerText);
		    }
		}
	}
	if(projectNames.length>0)
	{ 
			  document.getElementById('loadingDiv').style.display = '';
		      $.ajax({
		    	url: '/getDetails',
		        data: JSON.stringify({'projectName':projectNames}),
		        type: 'POST',
		        contentType: 'application/json;charset=UTF-8',
		    	success: function(response) 
			    {
			    	// alert(JSON.stringify(response));
			        if(response.result.success == true)
			        {
			        	detailsDiv.style.display = '';
			            var table = document.getElementById("detailsTable");
			            table.innerHTML = '';
			            var tr = document.createElement("TR");
			            var td7 = document.createElement("TD");
			           	td7.innerHTML = "Project";
			       		td7.style.padding = "5px 0px 5px 0px";
			       		td7.align = 'center';
			       		tr.appendChild(td7);

			       		var td0 = document.createElement("TD");
			           	td0.innerHTML = "User";
			       		td0.style.padding = "5px 0px 5px 0px";
			       		td0.align = 'center';
			       		tr.appendChild(td0);
			           

			       		var td1 = document.createElement("TD");
			       		td1.innerHTML = "Container";
			       		td1.style.padding = "5px 0px 5px 0px";
			       		td1.align = 'center';
			       		tr.appendChild(td1);

			       		var td2 = document.createElement("TD");
			       		td2.innerHTML = "File";
			       		td2.style.padding = "5px 0px 5px 0px";
			       		td2.align = 'center';
			       		tr.appendChild(td2);

			       		var td3 = document.createElement("TD");
			       		td3.innerHTML = "Last Modified";
			       		td3.style.padding = "5px 0px 5px 0px";
			       		td3.align = 'center';
			       		tr.appendChild(td3);

			       		var td4 = document.createElement("TD");
			       		td4.innerHTML = "Type";
			       		td4.style.padding = "5px 0px 5px 0px";
			       		td4.align = 'center';
			       		tr.appendChild(td4);

						var td5 = document.createElement("TD");
			       		td5.innerHTML = "Bytes";
			       		td5.style.padding = "5px 0px 5px 0px";
			       		td5.align = 'center';
			       		tr.appendChild(td5);

			       		var td6 = document.createElement("TD");
			       		td6.innerHTML = "Project";
			       		td6.style.padding = "5px 0px 5px 0px";
			       		td6.align = 'center';
			       		td6.style.display = 'none'
			       		tr.appendChild(td6);

			       		var td6 = document.createElement("TD");
			       		td6.innerHTML = "Download";
			       		td6.style.padding = "5px 0px 5px 0px";
			       		td6.align = 'center';
			       		// td6.style.display = 'none'
			       		tr.appendChild(td6);

			       		tr.style.background = "rgb(186, 219, 234)"
			       		table.appendChild(tr);
			       		var count =1 ;

			           for(var pro in response.result.data)
			           {
			           		var users = response.result.data[pro].projectUsers.join()
			           		for(var con in response.result.data[pro])
			           		{	
			           			if(con == "projectUsers"){continue;}
			           			for(var files in response.result.data[pro][con])
			           			{
				           			var tr = document.createElement("TR");
					           		tr.id = JSON.stringify(count).concat('r');
					           		if(count%2 == 0)
					           			{ tr.style.background = "#FFFFFF";
					           				}
					           		else
					           			{ tr.style.background = "#ebeff2";
					           				}
					           			
					           		var td8 = document.createElement("TD");
						           	td8.innerHTML = pro;
						       		td8.style.padding = "5px 0px 5px 0px";
						       		td8.align = 'center';
						       		tr.appendChild(td8);

						       		var td0 = document.createElement("TD");
						           	td0.innerHTML = users;
						       		td0.style.padding = "5px 0px 5px 0px";
						       		td0.align = 'center';
						       		tr.appendChild(td0);

					           		var td1 = document.createElement("TD");
					           		td1.innerHTML = con;
					           		td1.style.padding = "5px 0px 5px 0px";
					           		td1.align = 'center';
					           		tr.appendChild(td1);

					           		var td2 = document.createElement("TD");
					           		strlastModified = response.result.data[pro][con][files].lastModified;
					           		strcontentType = response.result.data[pro][con][files].contentType;
					           		strbytes = response.result.data[pro][con][files].bytes;
					           		files = wordWrap(files,15)
					           		strcontentType = wordWrap(strcontentType,15)
					           		td2.innerHTML = files;
					           		td2.style.padding = "5px 0px 5px 0px";
					           		td2.align = 'center';
					           		tr.appendChild(td2);

					           		var td3 = document.createElement("TD");
						       		td3.innerHTML = strlastModified;
						       		td3.style.padding = "5px 0px 5px 0px";
						       		td3.align = 'center';
						       		tr.appendChild(td3);

						       		var td4 = document.createElement("TD");
						       		td4.innerHTML = strcontentType;

						       		td4.style.padding = "5px 0px 5px 0px";
						       		td4.align = 'center';
						       		tr.appendChild(td4);

						       		var td5 = document.createElement("TD");

						       		rowID = '"'+JSON.stringify(count).concat('r')+'"'
						       		rowID = rowID.replace(/"/g,"&quot;")
						       		td5.innerHTML = strbytes;
						       		td5.style.padding = "5px 0px 5px 0px";
						       		td5.align = 'center';
						       		tr.appendChild(td5);

						       		var td6 = document.createElement("TD");
						       		td6.innerHTML = pro;
						       		td6.style.padding = "5px 0px 5px 0px";
						       		td6.align = 'center';
						       		td6.style.display = 'none'
						       		tr.appendChild(td6);

						       		var td7 = document.createElement("TD");
						       		td7.innerHTML = "<input name='Download' class='button1' type='button' value='Download' onclick='getRowValues("+rowID+")'/>";
						       		td7.style.padding = "5px 0px 5px 0px";
						       		td7.align = 'center';
						       		// td7.style.display = 'none'
						       		tr.appendChild(td7);

						       		count ++;
					           		table.appendChild(tr);
					           	}
				           	}

			           	}
			           	document.getElementById('loadingDiv').style.display = 'none';
			        }

			        else{
			        	$.notify("File cannot be loaded", "error");
			        	document.getElementById('loadingDiv').style.display = 'none';
			        }
			    }  
		    	});

	  		}
}

function selectAll(chk)
{
		
        var _rows = document.getElementById("dataTable").rows;
		   var i,
		       j,
		       isChecked,
		       inputs;
    // alert(_rows.length);	
   inputs = _rows[0].getElementsByTagName("input");
   isChecked = inputs[0].checked;	       
   for (i=0; i < _rows.length; i++) {
      inputs = _rows[i].getElementsByTagName("input");
      for (j=0; j < inputs.length; j++) {
         // if (inputs[j].className == "autocheck") {
         //    inputs[j].checked = isChecked;
         // }

         inputs[j].checked = isChecked;
      }
   }
        
}

function setCboAccount()
{
	var combo = document.getElementById("cboAccount");
	combo.innerHTML = '';
    for(pro in accDict)
    { 
	    var option = document.createElement("option");
	    option.text = pro;
	    option.value = pro;
	    combo.add(option);
	 }
	 setCboContainer();
}

function setCboContainer()
{
	document.getElementById("cboContainer").innerHTML = "";
	var account = document.getElementById("cboAccount").value;
	var combo = document.getElementById("cboContainer");
	var a = accDict[account];
	for(i=0;i<a.length;i++)
	{
		var option = document.createElement("option");
	    option.text = a[i];
	    option.value = a[i]
	    combo.add(option);
	}
}

function uploadFile()
{
	
	var file_pic = document.getElementById('pic').value.trim();
	if(file_pic != '')
	{
	document.getElementById('loadingDiv').style.display = '';	
	var formData = new FormData($('#fileUpload')[0]);
	document.getElementById('loadingDiv').style.display = 'none';
    $.ajax({
    	url: '/fileUpload',
        data: formData,
        type: 'POST',
        cache: false,
        contentType: false,
        processData: false,
        async: true,
    	success: function(response) 
	    {
	    	// alert(JSON.stringify(response));
	        if(response.result.success == true)
	        {
	           
	           $.notify("File send for uploading", "success");
	           document.getElementById('pic').value = '';

	           if(response.result.reload.ctype == "click")
	           {
	           	 tdClick('',response.result.reload.project);
	        	}
	        	else if(response.result.reload.ctype == "show")
	        	{
	        		showDetails();
	        	}
	        	else if(response.result.reload.ctype == "search")
	        	{
	        		searchFile();
	        	}
	        }

	        else{
	        	$.notify("Error while uploading file", "error");
	        	}
	    }  
    });
}
}

function wordWrap(str, maxWidth) 
{
	// alert(str);
    var newLineStr = "<br>";
    var res = '';
    if(maxWidth <str.length)
    {
    	
    	var count = 1;
    	var sliceint = 0;
    	for(var i=0;i<str.length;i++)
    	{
    		if(i >0 && parseInt(i/maxWidth) == count)
    		{
    			res = res+str.slice(sliceint,i)+newLineStr;
    			sliceint=i;
    			count++;
    		}
    		if(i+1 == str.length)
    		{
    			res = res+str.slice(sliceint,i);
    		}
    	}
    }
    if(res=='')
    	{res=str;}
    return res

}

function addProject()
{
	document.getElementById('addProjectDiv').style.display = '';
}

function projectCancel()
{
	document.getElementById('txtProject').value = '';
	document.getElementById('addProjectDiv').style.display = 'none';
}

function projectSave()
{
	
	var strProject = document.getElementById('txtProject').value.trim();
	if(strProject == ''){alert("Enter project ");document.getElementById('txtProject').focus();return false;}

	
	document.getElementById('loadingDiv').style.display = '';
	$.ajax({
	    	url: '/projectSave',
	        data: JSON.stringify({'project':strProject}),
	        type: 'POST',
	        contentType: 'application/json;charset=UTF-8',
	    	success: function(response) 
		    {
		    	// alert(JSON.stringify(response));
		        if(response.result.success == true)
		        {
		           	document.getElementById('loadingDiv').style.display = 'none';
		           	alert("Admin user is added to "+strProject);

		        }

		        else
		        {
		        	document.getElementById('loadingDiv').style.display = 'none';
		        	alert("Invalid project");

		        }
		    }  
	    });
}
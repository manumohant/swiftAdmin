from app import config,app,db,mail
from flask import render_template,request,jsonify,json,make_response,send_file,url_for
import datetime
from app.models import cURL,userModel
from app.models import globalMethod
from werkzeug import secure_filename
import os
import requests
from flask import session,redirect
import swiftclient
import thread
import copy
import StringIO
from flask_mail import Message
insCURL = cURL.CURL()
@app.route('/')
@app.route('/index')
def index():

    if session and session['authtoken']:
        strPro = 'none';
        if session['username'].lower() == 'admin':strPro='';
        return render_template('home.html',username=session['username'],project=strPro)
    return render_template('login.html')

@app.route('/checkLogin',methods=['POST','GET'])
def checkLogin():
    print "view checkLogin "
    data = request.json
    # import pdb;pdb.set_trace()
    blnValid = insCURL.checkLogin(data['userName'],data['password'],data['tenantName'])
    print "login status ----------------> ",blnValid
    print "view checkLogin finished"
    if blnValid:
        return jsonify(result = {'success':True})
    else:
        return jsonify(result = {'success':False})

@app.route('/home',methods=['POST','GET'])
def home():
    if not session or not session['authtoken']:
        return render_template('login.html')
    # import pdb;pdb.set_trace()
        
    return redirect('/')

@app.route('/download/<path:file_id>',methods=['POST','GET'])
def download(file_id):
    if not session['authtoken']:
        return render_template('login.html')

    lstFile = file_id.split('::')
    lstdata = insCURL.downloadFile(lstFile[0],lstFile[1],lstFile[2],insCURL)
    if not lstdata : return "Not authorized"
    strIO = StringIO.StringIO()
    for line in lstdata:
        strIO.write(line)
    strIO.seek(0)
    return send_file(strIO,
                     as_attachment=True,
                     attachment_filename=lstFile[1])
    
@app.route('/getFileDetails',methods=['POST','GET'])
def getFileDetails():
    #import pdb;pdb.set_trace()
    if session and session['authtoken']:
        # data = request.json
        insCURL.getFileDetails(insCURL)
        session["display"] = {"ctype":""}
        if insCURL.data:

            return jsonify(result = {'success':True,'data':insCURL.data})
        else:
            return jsonify(result = {'success':False,'data':insCURL.data})
    return redirect('/')    



@app.route('/logout',methods=['POST','GET'])
def logout():
    if session and session['authtoken']:
       session['authtoken'] = None
       session['username'] = None
       session['password'] = None
       session['tenantname'] = None
    return redirect('/')

@app.route('/getDetails',methods=['POST','GET'])
def getDetails():
    # import pdb;pdb.set_trace()
    if session and session['authtoken']:
        data = request.json
        projectName = data["projectName"]
        strType = type(projectName)
        
        if strType == list:
            data_temp = {}
            session["display"] = {"ctype":"show"}
            for proj in projectName:
                data_temp[proj] = insCURL.data[proj]
            return jsonify(result = {'success':True,'data':data_temp})

        session["display"] = {"ctype":"click","project":projectName}
        return jsonify(result = {'success':True,'data':insCURL.data[projectName],"project":projectName})
    return render_template('login.html')
        
@app.route('/aboutTools.html',methods=['POST','GET'])
def aboutTools():
    # import pdb;pdb.set_trace()
    return render_template('aboutTools.html')

@app.route('/searchFile',methods=['POST','GET'])
def searchFile():
    # import pdb;pdb.set_trace()
    data = request.json
    dfrom = data['from']
    to = data['to']
    file_name = data['file_name']
    account = data['account']
    container = data['container']
    # import pdb;pdb.set_trace()
    session["display"] = {"ctype":"search"}
    try:
        if dfrom and to:
            dfrom = datetime.datetime.strptime(dfrom,'%d/%m/%Y')
            to = datetime.datetime.strptime(to,'%d/%m/%Y')
    except:
        jsonify(result = {'success':False})
    else:
        data_temp = {}

        if insCURL.data:
           # import pdb;pdb.set_trace()
            if account:
                 data_temp = {xp : {} for xp in insCURL.data.keys() if xp.find(account) <> -1}
            elif not account:
                data_temp = {xp: {} for xp in insCURL.data.keys()}
            if not data_temp:
                return jsonify(result = {'success':False})

            #########################33
            for pro in data_temp.keys():
                if container:
                    data_temp[pro] = {xc:{} for xc in insCURL.data[pro].keys() if xc.find(container) <> -1}
                elif not container:
                    data_temp[pro] = {xc:{} for xc in insCURL.data[pro].keys()}

                data_temp[pro]['projectUsers'] = insCURL.data[pro]['projectUsers']
                

                for con in data_temp[pro].keys():
                    if con == 'projectUsers':
                        continue
                    if file_name:
                        data_temp[pro][con] = {xf:insCURL.data[pro][con][xf] for xf in insCURL.data[pro][con].keys() if xf.find(file_name) <> -1}
                    elif not file_name:
                        data_temp[pro][con] = {xf:insCURL.data[pro][con][xf] for xf in insCURL.data[pro][con].keys()}

                    if dfrom and to:
                        for files in data_temp[pro][con].keys():
                            # if data_temp[pro][con][files]['lastModified'].find('18') <> -1 : import pdb;pdb.set_trace()
                            if not datetime.datetime.strptime(data_temp[pro][con][files]['lastModified'].split(' ')[0],'%Y-%m-%d') >= dfrom or not datetime.datetime.strptime(data_temp[pro][con][files]['lastModified'].split(' ')[0],'%Y-%m-%d') <= to:
                                del(data_temp[pro][con][files])

            print data_temp     
            return jsonify(result = {'success':True,'data':data_temp})

@app.route('/fileUpload',methods=['POST','GET'])
def fileUpload():
    if not request.form.has_key('cboContainer') or not request.form.has_key('cboAccount'):
        return jsonify(result = {'success':False})

    con = request.form['cboContainer']
    project = request.form['cboAccount']
    file = request.files['pic']
    print "reading file ......"
    file_stream = file.stream
    print "reading file complete ..."
    con = request.form['cboContainer']
    project = request.form['cboAccount']
    strFileName = datetime.datetime.now().strftime('%d_%m_%Y_%H_%M_%S')+file.filename
    
    with open(os.environ['HOME']+'/swiftAdmin/backup/'+strFileName, 'wb') as my_hello:
        my_hello.write(file_stream.read())
    
    # buffer = []
    # buffer.append("Content-type: %s" % file.content_type)
    # buffer.append("File content: %s" % file.stream.read())


    blnStatus = insCURL.upload(strFileName,file.filename,project,con,insCURL)
    return jsonify(result = {'success':blnStatus,'reload':session["display"]})

@app.route('/signup',methods=['POST','GET'])
def signup():
    return render_template('signup.html')

@app.route('/register',methods=['POST','GET'])
def register():
    # import pdb;pdb.set_trace()
    data = request.json
    insUser = userModel.User()
    # id = db.Column(db.Integer, primary_key=True)
    # userName = db.Column(db.String(100), index=True)
    # password = db.Column(db.String(100), index=True)
    # account = db.Column(db.String(100), index=True)
    # status = db.Column(db.String(50), index=True)
    # createdDate = db.Column(db.TIMESTAMP, index=True)
    # registeredDate = db.Column(db.TIMESTAMP, index=True)
    # modifiedDate = db.Column(db.TIMESTAMP, index=True)
    # companyName = db.Column(db.String(100), index=True)
    # authToken = db.Column(db.TEXT, index=True)
    # expires = db.Column(db.Integer, index=True)
    # emailId = db.Column(db.String(100), index=True)

    result = db.engine.execute("""
                                SELECT id from tblUser
                                WHERE emailId = '%s' AND status <> 'deleted'
                                """%(data['emailId'])).fetchone()

    if result not in [(None,),None,(),[]]:
        return jsonify(result = {'success':False,'msg':'Email Id already registered'})

    insGlobalMethod = globalMethod.GlobalMethod()
    insUser.id = insGlobalMethod.getNextId('tblUser')
    insUser.userName = data['userName']
    insUser.emailId = data['emailId']
    insUser.companyName = data['companyName']
    insUser.status = 'created'
    insUser.registeredDate = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    blnStatus = insUser.insertIntoUser(insUser)
    strMsg = ""
    # import pdb;pdb.set_trace()
    if not blnStatus:
        strMsg = "Registration failure"

    msg = Message("swift registration",
                  sender="swiftvault@gamil.com",
                  recipients=["jayeshvijayan@fluentsoft.com"],
                  bcc=["fluentech@gmail.com"])   
    str_html = "Email ID : "+ insUser.emailId+"<br>"
    str_html += "User Name : "+insUser.userName+"<br>"
    str_html += "Company Name : "+insUser.companyName+"<br>"
    msg.html = str_html
    mail.send(msg)
    return jsonify(result = {'success':blnStatus,'msg':strMsg})

@app.route('/projectSave',methods=['POST','GET'])
def projectSave():
    # import pdb;pdb.set_trace()
    data = request.json
    strProject = data['project']
    blnStatus = insCURL.saveProject(strProject)
    return jsonify(result = {'success':blnStatus})














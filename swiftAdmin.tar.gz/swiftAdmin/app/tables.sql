CREATE TABLE tblUser(

		id INT NOT NULL PRIMARY KEY,
		userName VARCHAR(100) NOT NULL,
		password VARCHAR(100) DEFAULT '',
		account VARCHAR(100) DEFAULT '',
		status VARCHAR(50) NOT NULL,
		createdDate TIMESTAMP,
		modifiedDate TIMESTAMP,
		registeredDate TIMESTAMP,
		emailId VARCHAR(100),
		companyName VARCHAR(100),
		authToken TEXT,
        expires INT
		);
		


from app import db
from werkzeug import generate_password_hash, check_password_hash
from flask import session
import datetime

class User(db.Model):
    __tablename__ = 'tblUser'
    id = db.Column(db.Integer, primary_key=True)
    userName = db.Column(db.String(100), index=True)
    password = db.Column(db.String(100), index=True)
    account = db.Column(db.String(100), index=True)
    status = db.Column(db.String(50), index=True)
    createdDate = db.Column(db.TIMESTAMP, index=True)
    registeredDate = db.Column(db.TIMESTAMP, index=True)
    modifiedDate = db.Column(db.TIMESTAMP, index=True)
    companyName = db.Column(db.String(100), index=True)
    authToken = db.Column(db.TEXT, index=True)
    expires = db.Column(db.Integer, index=True)
    emailId = db.Column(db.String(100), index=True)

    def insertIntoUser(self,insUser):
        #insUser.password = generate_password_hash(insUser.password)
        try:
            db.session.add(insUser)
            db.session.commit()
        except:
            return False
        else:
            
            return True
        pass
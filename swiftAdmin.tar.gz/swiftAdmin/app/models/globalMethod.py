from app import db
class GlobalMethod(object):
	def __init__(self, *arg):
		pass

	def getNextId(self,tblName):
		result = db.engine.execute("""
									SELECT MAX(id) as id from %s
									"""%(tblName)).fetchone()

		if result not in [(None,),None,(),[]]:
			return result.id + 1
		else:
			return 1
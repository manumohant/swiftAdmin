from app import config
# from werkzeug import generate_password_hash, check_password_hash
from flask import session,json
import subprocess
import os,datetime

class CURL(object):
    projects = {}
    data = {}
    def __init__(self,*args):
        pass
    def checkLogin(self,userName,password,tenantName):
        cmd = ['curl', '-d', '{"auth":{"passwordCredentials":{"username": "'+userName+'","password": "'+password+'"},"tenantName": "'+tenantName+'"}}', '-H', 'Content-Type: application/json',config['identityUri']+'/tokens']
        # import pdb;pdb.set_trace()
        proc = subprocess.Popen(cmd, shell=False, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout,stderr =proc.communicate()
        print stdout
        try:
            stdout = json.loads(stdout)
        except Exception,msg:
            print msg
            return False
        else:
            if stdout and stdout.has_key('access'):
                if stdout['access'] and stdout['access'].has_key('token'):
                    if stdout['access']['token'] and stdout['access']['token'].has_key('id'):
                        session['authtoken'] = stdout['access']['token']['id']
                        session['username'] = userName
                        session['password'] = password
                        session['tenantname'] = tenantName
                        return True
        return False

    def getFileDetails(self,insCurl):
        # insCurl = CURL()
        insCurl.projects = {}
        insCurl.projectsName = {}
        insCurl.data = {}
        insCurl.users = {}
        # import pdb;pdb.set_trace()
        
        cmd = ['curl','-s','-H', 'X-Auth-Token:'+session['authtoken'],config['authUri']+'/v3/projects']
        proc = subprocess.Popen(cmd, shell=False, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout,stderr =proc.communicate()
        # print stdout
        try:
            stdout = json.loads(stdout)
        except Exception,msg:
            print msg
            return False
        else:
            if stdout and stdout.has_key('projects'):
                for pro in stdout['projects']:
                    insCurl.projects[pro['id']] = pro['name']
                    insCurl.projectsName[pro['name']] = pro['id']
            else:
                cmd = ['curl','-s','-H', 'X-Auth-Token:'+session['authtoken'],config['authUri']+'/v2.0/tenants']
                proc = subprocess.Popen(cmd, shell=False, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                stdout,stderr =proc.communicate()
                # print stdout
                try:
                    stdout = json.loads(stdout)
                except Exception,msg:
                    print msg
                    return False
                else:
                    if stdout and stdout.has_key('tenants'):
                        for pro in stdout['tenants']:
                            insCurl.projects[pro['id']] = pro['name']
                            insCurl.projectsName[pro['name']] = pro['id']

        if insCurl.projects:
            for pro in insCurl.projects:
                cmd = ['curl','-X','GET','-i','-H','X-Auth-Token:'+session['authtoken'],config['swiftAuthUrl']+'/AUTH_'+pro+'?format=json'] 
                proc = subprocess.Popen(cmd, shell=False, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                stdout,stderr =proc.communicate()
                stdout = stdout.split('\r\n')[11]
                try:
                    stdout = json.loads(stdout)
                except Exception,msg:
                    print msg
                    return False
                else:
                    if stdout:
                        insCurl.data[insCurl.projects[pro]]={}
                        for con in stdout:
                            insCurl.data[insCurl.projects[pro]][con['name']] = {}
                            cmd = ['curl','-X','GET','-i','-H','X-Auth-Token:'+session['authtoken'],config['swiftAuthUrl']+'/AUTH_'+pro+'/'+con['name']+'?format=json'] 
                            proc = subprocess.Popen(cmd, shell=False, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                            stdout1,stderr1 =proc.communicate()
                            stdout1 = stdout1.split('\r\n')[10]
                            try:
                                stdout1 = json.loads(stdout1)
                            except Exception,msg:
                                print msg
                            else:
                                if stdout1:
                                    # import pdb;pdb.set_trace()
                                    for files in stdout1:
                                        if files["bytes"] == 0: continue
                                        if files["last_modified"]:
                                            lastModified = (datetime.datetime.strptime(files["last_modified"].split('.')[0], '%Y-%m-%dT%H:%M:%S')).strftime('%Y-%m-%d %H:%M:%S')
                                        else:lastModified = ''

                                        insCurl.data[insCurl.projects[pro]][con['name']][files["name"]] = {'lastModified':lastModified,
                                                                                'bytes':files["bytes"],
                                                                                'contentType':files["content_type"]
                                                                                }
           
        # import pdb;pdb.set_trace()                                                                        
        cmd = ['curl','-s','-H','X-Auth-Token:'+session['authtoken'],config['authUri']+'/v3/users']
        proc = subprocess.Popen(cmd, shell=False, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout,stderr =proc.communicate()
        try:
            stdout = json.loads(stdout)
        except Exception,msg:
            print msg
            return False
        else:
            if stdout and stdout.has_key('users'):
                for users in stdout['users']:
                    if users.has_key('default_project_id'):
                        insCurl.users[insCurl.projects[users['default_project_id']]] = users['name']
        
        for proKey in insCurl.data:
            insCurl.data[proKey]["projectUsers"] = []
            for uProKey in insCurl.users:
                if proKey == uProKey:
                    if insCurl.data[proKey].has_key("projectUsers"):
                       insCurl.data[proKey]["projectUsers"].append(insCurl.users[uProKey])

        print insCurl.data
        return insCurl

    def downloadFile(self,con,fileName,project,insCURL):
        cmd = ['curl','-X','GET', 'X-Auth-Token:'+session['authtoken'],config['swiftAuthUrl']+'/AUTH_'+insCURL.projectsName[project]+"/"+con+"/"+fileName]
        proc = subprocess.Popen(cmd, shell=False, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout,stderr =proc.communicate()
        # stdout = stdout.split('\r\n')[10:]
        return stdout

    def upload(self,strfilename,file_name,project,con,insCURL):
        # import pdb;pdb.set_trace()
        # curl -X PUT -i -H "X-Auth-Token:X-Auth-Token:3f7be7741cb54d5282f77d870b699375"  http://10.0.2.15:8080/v1/AUTH_3a0127d14acc41cc9868677e11c511b9/con2 -T file_stream
        try:
            cmd = ['curl','-i',config['swiftAuthUrl']+'/AUTH_'+insCURL.projectsName[project]+"/"+con+"/"+file_name ,'-X','PUT','-H','X-Auth-Token:'+session['authtoken'],'-T',os.environ['HOME']+'/swiftAdmin/backup/'+strfilename]
            # cmd = ['curl','-X','PUT', 'X-Auth-Token:'+session['authtoken'],config['swiftAuthUrl']+'/AUTH_'+insCURL.projectsName[project]+"/"+con+"/"+file_name,'-T',file_name]
            proc = subprocess.Popen(cmd, shell=False, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout,stderr =proc.communicate()
        except:
            return False
        # stdout = stdout.split('\r\n')[10:]
        return True

    def saveProject(self,strProject):
        # import pdb;pdb.set_trace()
        try:
            cmd = ['openstack','--os-username', session['username'],'--os-password',session['password'],'--os-tenant-name',session['tenantname'],'--os-auth-url',config['authUri']+'/v2.0/','role add','--project',strProject,'--user','admin','admin']
            proc = subprocess.Popen(cmd, shell=False, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            stdout,stderr =proc.communicate()
        except:
            return False
        if stderr:
            return False
        return True



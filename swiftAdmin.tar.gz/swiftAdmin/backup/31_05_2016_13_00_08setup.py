# import os
# basedir = os.path.abspath(os.path.dirname(__file__))[:-4]
# def readConfig():
#   config = {}
#   fp = open(basedir+'/app.config','r')
#   lstData = fp.readlines()
#   print lstData
#   for i in lstData:
#       print i
#       if i[0] == '#':
#           continue
#       i = i.replace('\n','').replace('\t','').replace(' ','').replace('"','').replace("'",'')
#       if '=' in i:
#           config[i.split('=')[0].strip()] = i.split('=')[1].strip()
#   return config
import os
import subprocess
cmd = ['sudo','easy_install','python-virtualenv']
# import pdb;pdb.set_trace()
proc = subprocess.Popen(cmd, shell=False, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
stdout =proc.communicate()



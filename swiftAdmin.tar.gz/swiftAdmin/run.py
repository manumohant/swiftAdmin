#!flask/bin/python

# import pdb;pdb.set_trace()
# app.run(debug=True,host='10.0.2.15',port=8085,threaded=True)

# from tornado.wsgi import WSGIContainer
# from tornado.httpserver import HTTPServer
# from tornado.ioloop import IOLoop
# # from yourapplication import app
# from app import app

# http_server = HTTPServer(WSGIContainer(app))
# http_server.listen(8085)
# IOLoop.instance().start()

# activate_this = '/home/fluent/swiftApp/flask/bin/activate'
# execfile(activate_this, dict(__file__=activate_this))
import os
activate_this_file = os.environ['HOME']+'/swiftAdmin/flask/bin/activate_this.py'

execfile(activate_this_file, dict(__file__=activate_this_file))

from gevent.wsgi import WSGIServer
from app import app
# app.run(debug=True,host='192.168.1.9',port=8085,threaded=True)
http_server = WSGIServer(('', 8082), app)
http_server.serve_forever()
